//Библиотеки
#define _USE_MATH_DEFINES
#include <cmath>
#include <fstream>
#include <algorithm>
#include <iomanip>
#include <vector>
#include <queue>
//using namespace std;

//structs
struct Point
{
	double x, y;
};

struct Line //НЕЛЬЗЯ ВЕРТИКАЛЬНЫЕ ПРЯМЫЕ ЮЗАТЬ С ЭТОЙ СТРУКТУРОЙ!!!!
{
	double k, d;
};


//function

Line getline(Point a, Point b) //из двух точек делает прямую//НЕЛЬЗЯ ВЕРТИКАЛЬНЫЕ ПРЯМЫЕ ЮЗАТЬ С ЭТОЙ СТРУКТУРОЙ!!!!
{
	Line f;
	if (a.x == b.x)
	{
		return f;
	}
	f.k = (double)(b.y - a.y) / (b.x - a.x);
	f.d = (double)a.y - f.k*a.x;
	return f;
}

double Dis(Point a, Point b)
{
	return sqrt((a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y));
}

double Area(Point A, Point B, Point C)
{
	double a = Dis(A, B);
	double b = Dis(C, B);
	double c = Dis(A, C);
	double p = (a + b + c) / 2;
	return sqrt(p*(p - a)*(p - b)*(p - c));
}

bool inTriangle(Point a, Point b, Point c, Point v) //лежит ли точка внутри триугольника? и esp означает погрешность
{
	double esp = 0.00001;
	double S = Area(a, b, c);
	double s1 = Area(a, b, v);
	double s2 = Area(a, v, c);
	double s3 = Area(v, b, c);
	if (S>s1 + s2 + s3 - esp&&S<s1 + s2 + s3 + esp)
		return true;
	return false;
}

bool PInLine(Point A, Line l)
{
	double esp = 0.0000000001;
	if (A.y<l.k*A.x + l.d + esp&&A.y>l.k*A.x + l.d - esp)
		return true;
	return false;
}

Point interP(Line A, Line B) //точка пересечения 2-х прямых, возвращает INT_MAX если она паралельны
{
	Point ans;
	if (A.k == B.k)
	{
		ans.x = (double)INT_MAX;
		ans.y = (double)INT_MAX;
		return ans;
	}
	else
	{
		ans.x = (B.d - A.d) / (A.k - B.k);
		ans.y = A.k*ans.x + A.d;
	}
	return ans;
}

bool InXangle(vector <Point> v, Point f)//возвращает, лежит ли точка внутри Х-угольника, на вход подавать вектор из точек(вершины) и точку, для которой хотим проверить
{
	int k = v.size();
	for (int i = 0; i<k; i++)
		for (int j = i + 1; j<k; j++)
			for (int m = j + 1; m<k; m++)
			{
				if (inTriangle(v[i], v[j], v[m], f))
					return true;
			}
	return false;
}

bool Perpendicular(Line A, Line B)
{
	if (A.k*B.k == -1)
		return true;
	return false;
}

double AngleGradus(Line A, Line B)// возвращает в градусах угол между двумя прямыми
{
	return abs(atan(A.k) - atan(B.k)) * 180 / M_PI;
}
double AngleRadian(Line A, Line B) //возвращает в радианах угол между двумя прямыми
{
	return abs(atan(A.k) - atan(B.k));
}
double DisToLine(Line A, Point B)
{
	return abs(A.k*B.x - B.y + A.d) / sqrt(A.k*A.k + 1);
}
