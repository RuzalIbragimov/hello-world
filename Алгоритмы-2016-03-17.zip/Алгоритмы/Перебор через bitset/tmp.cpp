#include <fstream>
#include <cmath>
#include <vector>
#include <map>
#include <algorithm>
#include <cmath>
#include <bitset>

using namespace std;
//ifstream cin("input.txt"); ofstream cout("output.txt");
ifstream cin("registration.in"); ofstream cout("registration.out");
int n, m, a, b, h;
bool f()
{
	if (n == 0 || m == 0)
	{
		if (n == 0&&m==0)
		{
			return true;
		}
		if (n == 0)
		{
			if (m <= b)
				return true;
		}
		if (m == 0)
		{
			if (n <= a)
				return true;
		}
		return false;
	}
	if (m == 1 || n == 1)
	{
		if (n == 1)
		{
			if (m - m / 2 > b)
				return false;
		}
		if (m == 1)
		{
			if (n - n / 2 > a)
				return false;
		}
		return true;
	}
	if (a == 1 || b == 1)
	{
		if (a == 1)
		{
			if ((n + 1)*b >= m && (m + 1) >= n)
			{
				return true; 
			}
			if ((m - 1) >= n && (n-1)*b>=m)
			{
				return true;
			}
		}
		if (b == 1)
		{
			if ((m + 1)*a >= n && (n + 1) >= m)
			{
				return true; 
			}
			if ((n - 1) >= m && (m - 1)*a >= n)
			{
				return true;
			}
		}
		return false;
	}

	if (((n + a - 1) / a + 1)*b<m)
	{
		int p = m - ((n + a - 1) / a)*b;
		int k = n / a*(a - 1) + max(0, n%a - 1);
		if ((k + 1)*b >= p)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	if (((m + b - 1) / b + 1)*a<n)
	{
		int p = n - ((m + b - 1) / b)*a;
		int k = m / b*(b - 1) + max(0, m%b - 1);
		if ((k + 1)*a >= p)
		{
			return true;
		}
		else
		{
			return false;
		}
		 
	}

	if (((n + a - 1) / a + 1)*b >= m)
	{
		return true;	 
	}
	if (((m + b - 1) / b + 1)*a >= n)
	{
		return true;
		 
	}
	return false;
}

bool solve()
{
	bool f;
	for (int i = 1; i <= pow(2, n + m); i++)
	{
		f = true;
		bitset <20> x(i);
		int g = 0, k = 0,gb=0,kb=0;
		for (int j = 0; j <(n + m); j++)
		{
			if (x[j] == 1)
			{
				k++;
				kb++;
				g = 0;
			}
			else
			{
				g++;
				gb++;
				k = 0;
			}
			if (k > b || g > a||gb>n||kb>m)
			{
				f = false;
				break;
			}
		}
		if (f&&kb==m&&gb==n)
		{
			return true;
		}
	}
	return false;
}

int main()
{
	cin >>h>> n >> m >> a >> b;
	if (h == 1&&f())
	{
		cout << "YES" << endl << "GGBBGG";
		return 0;
	}
	if (f())
	{
		cout << "YES";
	}
	else
	{
		cout << "NO";
	}
	
	return 0;
	int fgh = 0;
	for (n = 1; n < 20; n++)
	{
		for (m = 1; m < 20; m++)
		{
			if (n + m>20)
				break;
			for (a = 1; a < 20; a++)
			{
				if (a > n)
					break;
				for (b = 1; b < 20; b++)
				{
					if (b > m)
						break;
					if (f() != solve())
					{
						cout << n << " " << m << " " << a << " "<<b<<endl;
						return 0;
					}
				}
			}
		}
	}

	return 0;
}