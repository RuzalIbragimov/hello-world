/*
ID: GoToCoding
PROG: ride
LANG: C++11
*/

#include <cmath>
#include <vector>
#include <iostream>
#include <set>
#include <bitset>
#include <algorithm>
#include <map>
#include <string>
#include <iomanip>
#include <climits>
#include <queue>
#include <ctime>
#include <cassert>
#include <cstdio>
#include <stack>
#include <cstdlib>
#include <cstring>
#include <list>
#include <tuple>

#define m_pi 3.14159265358979323846
#define v1 (2*v+1)
#define v2 (2*v+2)
#define ll long long
#define ull unsigned long long
#define forn(it, a, b) for(auto it = a; it < b; it++)
#define what_is(x) cout << #x << " is " << x << endl;

using namespace std;

ll gcd(ll a, ll b)
{
	while (a)
	{
		if (a < b) swap(a, b);
		a = a%b;
	}
	return b;
}
bool prime(ll x)
{
	if (x == 1) return false;
	ll k = sqrt(x) + 1;
	forn(i, 2, k) if (x%i == 0)return false;
	return true;
}
ll binpow(ll a, ll n, ll mod) {
	ll res = 1;
	while (n){
		if (n & 1) {
			res = (res * a) % mod;
			--n;
		}
		else {
			a = (a * a) % mod;
			n >>= 1;
		}
	}
	return res;
}
ll gcd() { return 1; }
template<typename... Args>
ll gcd(ll a, ll b, Args... args) { return gcd(__gcd(a, b), args...); }
ll phi(ll n) {
	ll result = n;
	for (ll i = 2; i*i <= n; ++i)
		if (n % i == 0) {
		while (n % i == 0)
			n /= i;
		result -= result / i;
		}
	if (n > 1)
		result -= result / n;
	return result;
}
inline void read(ll &x){
	char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	x = 0;
	while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
}

int it_rnd = 0;
const int maxn = 1000;
int rnd[maxn];

struct node {
	ll val, p;
	ll size;
	node *l, *r;
	node() {}
	node(ll v, ll pr) {
		val = v;
		p = pr;
		size = 1;
		l = NULL;
		r = NULL;
	}
};

typedef node* pt; // pointer

pt root;

ll getsize(pt nroot) {
	return nroot ? nroot->size : 0;
}

void fixsize(pt nroot) {
	nroot->size = getsize(nroot->l) + getsize(nroot->r) + 1;
}

pt merge(pt left, pt right) {
	if (left == NULL) return right;
	if (right == NULL) return left;
	if (left->p > right->p) {
		left->r = merge(left->r, right);
		fixsize(left);
		return left;
	}
	else {
		right->l = merge(left, right->l);
		fixsize(right);
		return right;
	}
}

void split(pt nroot, ll key, pt &left, pt &right) {
	if (nroot == NULL) {
		left = right = NULL;
		return;
	}
	ll nkey = getsize(nroot->l) + 1;
	if (nkey <= key) {
		
		split(nroot->r, key - nkey, left, right);
		nroot->r = left;
		left = nroot;
		fixsize(nroot);
	}
	else {
		split(nroot->l, key, left, right);
		nroot->l = right;
		right = nroot;
		fixsize(nroot);
	}

}

void add(ll pos, ll val) {
	if (root == NULL) {
		root = new node(val, rnd[it_rnd++]);
		return;
	}
	pt l, r, m;
	split(root, pos, l, r);
	m = new node(val, rnd[it_rnd++]);
	root = merge(l, merge(m, r));
}

void remove(ll pos) {
	pt l, r, m;
	split(root, pos, l, r);
	split(r, 1, m, r);
	root = merge(l, r);
}

ll get(ll pos) {
	pt l, r, m;
	split(root, pos, l, r);
	split(r, 1, m, r);
	ll ans = m->val;
	root = merge(l, merge(m, r));
	return ans;
}

void toBegin(ll a, ll b) { // b - �� �����.
	pt l, r, m;
	split(root, a, l, r);
	split(r, b - a, m, r);
	root = merge(m, merge(l, r));
}

int main()
{
	//
	ios::sync_with_stdio(false);
	//	

#if _DEBUG
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#else
#endif

	forn(i, 0, maxn) {
		rnd[i] = i;
	}
	random_shuffle(rnd, rnd + maxn);

	int n, k;
	cin >> n >> k;
	forn(i, 0, n) {
		int t;
		cin >> t;
		add(i, t);
	}

	//remove(1);
	//cout << getsize(root) << endl;
	while (k--) {
		int li, ri;
		cin >> li >> ri;
		li--;
		toBegin(li, ri);
	}
	
	forn(i, 0, n) {
		cout << get(i) << " "; 
	}

	return 0;
}