#include <bits/stdc++.h>
using namespace std;

#define ll long long

int it_rnd = 0;
const ll maxn = 1200999;
int rnd[maxn];

struct node {
	int val, p, min;
	int size;
	bool reverse;
	node *l, *r;
	node() {}
	node(int v, int pr) {
		val = v;
		reverse = false;
		p = pr;
		min = v;
		size = 1;
		l = NULL;
		r = NULL;
	}
};

typedef node* pt;

pt root;

int getsize(pt T) {
	return T ? T->size : 0;
}

int min_of(pt T) {
	if(!T) return INT_MAX;
	return T->min;
}

void recalc(pt T) {
	if (T) {
		T->size = getsize(T->l) + getsize(T->r) + 1;
		T->min = min(T->val, min(min_of(T->l), min_of(T->r)));
	}
}

void push(pt T) {
	if(T->reverse) {
		if(T->l) {
			T->l->reverse^=1;
		}
		if(T->r) {
			T->r->reverse ^=1;
		}
		swap(T->l, T->r);
		T->reverse = false;
	}
}

pt merge(pt left, pt right) {
	if (left == NULL) return right;
	if (right == NULL) return left;
	push(left);
	push(right);
	if (left->p >= right->p) {
		left->r = merge(left->r, right);
		recalc(left);
		return left;
	}
	else {
		right->l = merge(left, right->l);
		recalc(right);
		return right;
	}
}

pair<pt, pt> split(pt T, int key, int left = 0) {
	if (T == NULL) {
		return {NULL, NULL};
	}
	push(T);
	int x = left + getsize(T->l) + 1;
	if (x <= key) {
		auto tmp = split(T->r, key, x);
		T->r = tmp.first;
		recalc(T);
		return {T, tmp.second};
	} else {
		auto tmp = split(T->l, key, left);
		T->l = tmp.second;
		recalc(T);
		return {tmp.first, T};
	}

}

void print_tree(pt T) {
	if(T) {
		if(T->l)
			print_tree(T->l);
		cout << T->val << " ";
		if(T->r)
			print_tree(T->r);
	}
}

int get_min(int l, int r) {
	auto tmp = split(root, r);
	auto tmp2 = split(tmp.first, l - 1);
	int ans = tmp2.second->min;
	root = merge(merge(tmp2.first, tmp2.second), tmp.second);
	return ans;
}

void add(int pos, int x) {
	if (root == NULL) {
		root = new node(x, rnd[it_rnd++]);
		return;
	}
	pt m = new node(x, rnd[it_rnd++]);
	auto tmp = split(root, pos - 1);
	root = merge(merge(tmp.first, m), tmp.second);
}

void reverse(int l, int r) {
	auto tmp = split(root, r);
	auto tmp2 = split(tmp.first, l - 1);
	tmp2.second->reverse ^= 1;
	root = merge(merge(tmp2.first, tmp2.second), tmp.second);
}

int get_pos(int x) {
	auto tmp = split(root, x);
	auto tmp2 = split(tmp.first, x - 1);
	int ans = tmp2.second->val;
	root = merge(merge(tmp2.first, tmp2.second), tmp.second);
	return ans;
}

int main() {
	ios::sync_with_stdio(false);
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	//srand(time(NULL));
	for(int i = 0; i < maxn; i++) {
		rnd[i] = i;
	}
	random_shuffle(rnd, rnd + maxn);

	int n, m;
	cin >> n >> m;

	for(int i = 1; i <= n; i++) {
		int x;
		cin >> x;
		add(i, x);
	}

	while(m--) {
		int l, r, t;
		cin >> t >> l >> r;
		if(t == 1) {
			reverse(l, r);
		} else {
			cout << get_min(l, r) << '\n';
		}
	}



	return 0;

}