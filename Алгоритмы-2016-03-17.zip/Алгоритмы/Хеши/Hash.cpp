#include <vector>
#include <cmath>
#include <fstream>
#include <string>
#define int_max 2147483647
using namespace std;

ifstream cin("input.txt");
ofstream cout("output.txt");

vector <int> v;
int sizeN;

int hash(int p)
{
	return (p-1)*19%sizeN;//any KEY for hash
}

void Add(int p)
{
	int k=hash(p);
	if(v[k]==int_max)
	{
		v[k]=p;
		return;
	}
	for(int i=k;i<3*sizeN;i++)
	{
		if(v[i]==int_max)
			{
				v[i]=p;
				return;
			}
	}

}

bool Find(int p)
{
	int k=hash(p);
	if(v[k]==int_max)
		return false;
	for(int i=k;i<3*sizeN;i++)
	{
		if(v[i]==p)
			return true;
		if(v[i]==int_max)
			return false;
	}
	return false;
}

int main()
{
	int tmp;
	cin>>sizeN;
	v.resize(3*sizeN);
	for(int i=0;i<3*sizeN;i++)
	{
		v[i]=2147483647; //int_max
	}
	for(int i=0;i<sizeN;i++)
		{
			cin>>tmp;
			Add(tmp);
		}
	int kolvoZaprosov;
	cin>>kolvoZaprosov;
	for(int i=0;i<kolvoZaprosov;i++)
	{
		cin>>tmp;
		if(Find(tmp))
		{
			cout<<"YES";
		}
		else
		{
			cout<<"NO";
		}
		cout<<endl;
	}
	return 0;
}